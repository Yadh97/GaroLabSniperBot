# Main bot logic here
print('Bot running')